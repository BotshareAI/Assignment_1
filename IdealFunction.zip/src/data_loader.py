# Handles CSV and DB loading
