# Contains core logic for LSQ matching
