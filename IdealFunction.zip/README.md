# Ideal Function Assignment

This project addresses the assignment from DLMDSPWP01. It involves selecting ideal mathematical functions based on training data, mapping test data, and visualizing results.
