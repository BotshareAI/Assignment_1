# Ideal Function Assignment

This repository contains the code for solving the ideal function assignment in Python.