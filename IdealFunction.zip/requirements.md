# Requirements

- pandas
- numpy
- bokeh
- sqlite3 (built-in)